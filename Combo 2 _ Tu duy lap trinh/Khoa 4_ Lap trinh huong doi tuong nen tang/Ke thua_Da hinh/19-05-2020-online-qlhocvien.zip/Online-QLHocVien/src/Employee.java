import java.util.Scanner;

/*
 * Mục đích: Xử lý nghiệp vụ cho lớp Employee
 * Người tạo: CyberLearn
 * Ngày tạo: 26/4/2020
 * Version: 1.0
 * */
public class Employee extends Person {

	// 1. Attributes
	private float soNgayLamViec;
	private int luongTheoNgay;
	// 2. get, set
	
	/**
	 * @return the soNgayLamViec
	 */
	public float getSoNgayLamViec() {
		return soNgayLamViec;
	}

	/**
	 * @param soNgayLamViec the soNgayLamViec to set
	 */
	public void setSoNgayLamViec(float soNgayLamViec) {
		this.soNgayLamViec = soNgayLamViec;
	}

	/**
	 * @return the luongTheoNgay
	 */
	public int getLuongTheoNgay() {
		return luongTheoNgay;
	}

	/**
	 * @param luongTheoNgay the luongTheoNgay to set
	 */
	public void setLuongTheoNgay(int luongTheoNgay) {
		this.luongTheoNgay = luongTheoNgay;
	}

	// 3. constructors
	public Employee() {
		
	}

	public Employee(String hoTen, String diaChi, String ma, String email, int luong, int soNgay) {
		super(hoTen, diaChi, ma, email);
		this.soNgayLamViec = soNgay;
		this.luongTheoNgay = luong;
	}
	// 4. input, output
	@Override
	public void nhap(Scanner scan) {
		super.nhap(scan);
		System.out.print("Lương theo ngày: ");
		this.luongTheoNgay = Integer.parseInt(scan.nextLine());
		System.out.print("Số ngày làm việc: ");
		this.soNgayLamViec = Integer.parseInt(scan.nextLine());
	}
	
	@Override 
	public void xuat() {
		super.xuat();
		System.out.println("\t Lương/ngày: " + this.luongTheoNgay + "\t Số ngày làm việc;" + this.soNgayLamViec);
	}
	// 5. business
	

}
