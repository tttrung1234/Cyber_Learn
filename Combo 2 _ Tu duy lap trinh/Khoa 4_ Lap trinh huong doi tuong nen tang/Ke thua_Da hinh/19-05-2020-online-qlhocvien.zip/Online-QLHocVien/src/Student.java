import java.util.Scanner;

/**
 * Mục đích: Tạo lớp quản lý các Students
 * Người tạo: Cyberlearn
 * Ngày tạo: 25/4/2020
 * Version: 1.0
 */

/**
 * @author lequangsong
 *
 */
public class Student extends Person {

	// 1. Attributes
	private float toan;
	private float ly;
	private float hoa;
	// 2. get, set
	
	/**
	 * @return the toan
	 */
	public float getToan() {
		return toan;
	}

	/**
	 * @param toan the toan to set
	 */
	public void setToan(float toan) {
		this.toan = toan;
	}

	/**
	 * @return the ly
	 */
	public float getLy() {
		return ly;
	}

	/**
	 * @param ly the ly to set
	 */
	public void setLy(float ly) {
		this.ly = ly;
	}

	/**
	 * @return the hoa
	 */
	public float getHoa() {
		return hoa;
	}

	/**
	 * @param hoa the hoa to set
	 */
	public void setHoa(float hoa) {
		this.hoa = hoa;
	}

	// 3. constructor
	public Student() {
		
	}
	
	
	/**
	 * @param toan
	 * @param ly
	 * @param hoa
	 */
	public Student(float toan, float ly, float hoa) {
		super();
		this.toan = toan;
		this.ly = ly;
		this.hoa = hoa;
	}
	
	/**
	 * @param hoTen
	 * @param diaChi
	 * @param ma
	 * @param email
	 */
	
	public Student(String hoTen, String diaChi, String ma, String email, float toan, float ly, float hoa) {	
		super(hoTen, diaChi, ma, email);
		this.toan = toan;
		this.ly = ly;
		this.hoa = hoa;
	}
	
	// 4. input, output
	@Override
	public void nhap(Scanner scan) {
		super.nhap(scan);
		System.out.print("Nhập điểm toán: ");
		this.toan = Float.parseFloat(scan.nextLine());
		
		System.out.print("Nhập điểm lý: ");
		this.ly = Float.parseFloat(scan.nextLine());
		
		System.out.print("Nhập điểm hoa: ");
		this.hoa = Float.parseFloat(scan.nextLine());
	}
	
	@Override
	public void xuat() {
		super.xuat();
		System.out.println("\t Toán: " + this.toan + "\t Lý:  " + this.ly + "\t Hóa: " + this.hoa);
	}
	
	// 5. business
	

	

}
