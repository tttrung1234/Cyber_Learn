import java.util.Scanner;

/*
 * Mục đích: Quản lý nghiệp vụ cho Customer
 * Ngày tạo: 26/4/2020
 * Người tạo: CyberLearn
 * Version: 1.0
 * */
public class Customer extends Person {

	// 1. attributes
	private String tenCongTy;
	private float triGiaHoaDon;
	private String danhGia;
	// 2. get, set
	
	/**
	 * @return the tenCongTy
	 */
	public String getTenCongTy() {
		return tenCongTy;
	}

	/**
	 * @param tenCongTy the tenCongTy to set
	 */
	public void setTenCongTy(String tenCongTy) {
		this.tenCongTy = tenCongTy;
	}

	/**
	 * @return the triGiaHoaDon
	 */
	public float getTriGiaHoaDon() {
		return triGiaHoaDon;
	}

	/**
	 * @param triGiaHoaDon the triGiaHoaDon to set
	 */
	public void setTriGiaHoaDon(float triGiaHoaDon) {
		this.triGiaHoaDon = triGiaHoaDon;
	}

	/**
	 * @return the danhGia
	 */
	public String getDanhGia() {
		return danhGia;
	}

	/**
	 * @param danhGia the danhGia to set
	 */
	public void setDanhGia(String danhGia) {
		this.danhGia = danhGia;
	}

	// 3. constructors
	public Customer() {
		
	}

	public Customer(String hoTen, String diaChi, String ma, String email, String tenCty, float triGia,String _danhGia ) {
		super(hoTen, diaChi, ma, email);
		this.tenCongTy = tenCty;
		this.triGiaHoaDon = triGia;
		this.danhGia = _danhGia;
	}
	// 4. input, output
	@Override
	public void nhap(Scanner scan) {
		super.nhap(scan);
		System.out.print(" Tên Công ty:");
		this.tenCongTy = scan.nextLine();
		System.out.print("Trị giá hóa đơn: ");
		this.triGiaHoaDon = Float.parseFloat(scan.nextLine());
		System.out.println(" Đánh giá:");
		this.danhGia = scan.nextLine();
	}
	
	@Override
	public void xuat() {
		super.xuat();
		System.out.println("\t Tên công ty: " + this.tenCongTy 
							+ "\t Trị giá hóa đơn: " + this.triGiaHoaDon
							+"\t Đánh giá: " + this.danhGia);
	}
	// 5. business


}
