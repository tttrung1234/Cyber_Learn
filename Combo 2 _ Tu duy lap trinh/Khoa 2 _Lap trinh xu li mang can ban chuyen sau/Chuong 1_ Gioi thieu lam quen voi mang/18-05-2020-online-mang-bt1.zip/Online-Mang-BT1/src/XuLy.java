import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Nhập vào số phần tử n = ");
		int n = Integer.parseInt(scan.nextLine());
		int a[] = nhapMang(n, scan);
		xuatMangForEach(a);
		float tong = tinhTongChan(a);
		xuatMangForEach(a);
		System.out.println("\nTổng các số chẵn trong mảng: " + tong);
		int dem = demSoAm(a);
		System.out.println("Mảng có " + dem + " số âm.");
		int tongAm = tongAm(a);
		System.out.println("Tổng các số âm là " + tongAm);

	}

	public static int[] nhapMang(int n, Scanner scan) {
		int a[] = new int[n];
		System.out.println("Nhập mảng");
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "] = ");
			a[i] = Integer.parseInt(scan.nextLine());
		}
		return a;

	}

	public static void xuatMangForI(int a[]) {
		System.out.println("Xuất mảng");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + "\t");
		}
	}

	public static void xuatMangForEach(int a[]) {
		System.out.println("\nXuất mảng");
		for (int pt : a) {
			System.out.print(pt + "\t");
		}
	}

	public static float tinhTongChan(int a[]) {
		float tong = 0;
		for (int pt : a) {
			if (pt % 2 == 0) {
				tong += pt;
			}
		}

//		for(int i = 0; i < a.length; i++) {
//			if(a[i] % 2 == 0) {
//				tong += a[i];
//			}
//		}
		return tong;
	}

	public static int demSoAm(int a[]) {
		int dem = 0;
		for (int pt : a) {
			if (pt < 0) {
				dem++;
			}
		}
		return dem;
	}

	public static int tongAm(int a[]) {
		int tong = 0;
		for (int item : a) {
			if (item < 0) {
				tong += item;
			}
		}
		return tong;
	}

}
