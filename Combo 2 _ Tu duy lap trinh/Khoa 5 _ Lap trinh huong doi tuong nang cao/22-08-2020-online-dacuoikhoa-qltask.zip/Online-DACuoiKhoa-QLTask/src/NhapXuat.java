//Đây là Interface giúp xử lý nhập xuất 
public interface NhapXuat {
	void xuat();
}
