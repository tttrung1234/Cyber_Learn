
public class TruongPhong extends NhanSu {
	//1. Attributes
	//2. Get, set
	//3. constructor
	public TruongPhong() {
		super();
	}
	
	public TruongPhong(String maNV, String tenNV, String namSinh, String email, String soDienThoai,String maPhongBan,
			float soNgayLamViec) {
		super(maNV, tenNV, namSinh, email, soDienThoai, maPhongBan, soNgayLamViec);
	}
	//4. input, out
	//5. Business methods
	
	@Override
	public void tinhLuong() {
		// TODO Auto-generated method stub

	}

}
