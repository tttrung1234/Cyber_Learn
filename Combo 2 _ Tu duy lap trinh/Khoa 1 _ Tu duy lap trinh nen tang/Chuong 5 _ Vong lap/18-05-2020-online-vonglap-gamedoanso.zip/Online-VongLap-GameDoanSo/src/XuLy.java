import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		doanSo(scan);

	}
	
	public static void doanSo(Scanner scan) {
		int soBiMat = (int) (Math.random() * 999 + 1);
		int nhap;
		do {
			System.out.println("Vui lòng nhập vào một số từ 1 - 999");
			nhap = Integer.parseInt(scan.nextLine());
			if(nhap < soBiMat) {
				System.out.println("Vui lòng nhập vào số lớn hơn");
			} else if(nhap > soBiMat) {
				System.out.println("Vui lòng nhập vào bé hơn");
			}
		} while( soBiMat != nhap);
		System.out.println("Chúc mừng chiến thắng");
	}

}
