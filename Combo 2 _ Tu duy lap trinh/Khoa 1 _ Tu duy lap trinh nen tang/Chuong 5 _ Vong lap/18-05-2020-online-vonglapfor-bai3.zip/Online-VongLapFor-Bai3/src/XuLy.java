import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Mời nhập vào số n: ");
		int n = Integer.parseInt(scan.nextLine());
		xuLySo(n);
		//int dem = demSoChiaHetCho3(n);
		//System.out.println("Có " + dem + " từ 0 đến " + n + " chia hết cho 3");
	}

	public static int demSoChiaHetCho3(int n) {
		int dem = 0;
		for (int i = 0; i < n; i++) {
			if (i % 3 == 0) {
				dem++;
			}
		}
		return dem;
	}

	public static void xuLySo(int n) {
		int soBanDau; // biến tạm để tách số
		soBanDau = n; // gán bằng số n ban đầu
		int soDangTach;// tách dần theo thứ tự sẽ được các chữ số hàng đơn vị lên trước
		int tongCacSo = 0;
		int dem = 0;
		do {
			soDangTach = soBanDau % 10;
			dem++;
			tongCacSo += soDangTach;
			soBanDau /= 10; // soBanDau = soBanDau/10;
		} while (soBanDau != 0);// phép chia nguyên nên khi soBanDau < 10 sẽ trả về 0

		System.out.println("Số " + n + " có " + dem + " chữ số.");
		System.out.println("Chữ số cuối cùng là: " + n % 10);
		System.out.println("Chữ số đầu tiên là: " + soDangTach); // số đầu tiên chính là lượt tách cuối cùng
		System.out.println("Tổng các chữ số là: " + tongCacSo);

		// Đảo số
		// Loại bỏ các số 0 ở đầu
		System.out.print("Số đảo ngược của n =  " + n + " là ");
		while (n % 10 == 0) {
			n /= 10; // n = n/10
		}
		do {
			System.out.print("" + n % 10);
			n /= 10;
		} while (n != 0);
	}

}
