import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static int timSoLonNhat(int a, int b, int c) {
		int soLonNhat = a;
		if (b > soLonNhat) {
			soLonNhat = b;
		}
		if (c > soLonNhat) {
			soLonNhat = c;
		}
		return soLonNhat;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//Thông báo cho người dùng nhập vào 3 số
		System.out.println("Chương trình tìm số lớn nhất trong 3 số");
		System.out.print("Mời nhập số thứ nhất: ");
		int x = Integer.parseInt(scan.nextLine());
		System.out.print("Mời nhập số thứ hai: ");
		int y = Integer.parseInt(scan.nextLine());
		System.out.print("Mời nhập số thứ ba: ");
		int z = Integer.parseInt(scan.nextLine());
		
		int max = timSoLonNhat(x, y, z);
		System.out.println("Max trong 3 số là: " + max);

	}

}
