import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	public static float tong3So(float a, float b, float c) {
		float kq = a + b + c;
		return kq;
	}

	public static void main(String[] args) {
		boolean flag = true;
		Scanner scan = new Scanner(System.in);
		int sum = 0;
		while (flag) {

			System.out.println("Nhập số lớn hơn ko");
			int num = Integer.parseInt(scan.nextLine());
			if (num > 0) {
				sum += num;
			} else {
				flag = false;
			}

		}
		System.out.println(sum);

	}

}
