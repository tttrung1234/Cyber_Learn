import java.util.Scanner;

public class XuLy {

	public XuLy() {
		// TODO Auto-generated constructor stub
	}

	// Hàm kiểm tra chẵn lẻ
	public static void kiemTraChanLe(int a) {
		//boolean kQua;
		if (a % 2 == 0) {// so chẵn
			//kQua = true;
			System.out.println("Là số chẵn");
		} else {
			//kQua = false; // số lẻ
			System.out.println("Là số lẻ");
		}
		//return kQua;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Chương trình kiểm tra một số là số lẻ hay chẵn");
		System.out.println("Mời nhập số để kiểm tra");
		int so = Integer.parseInt(scan.nextLine());
		kiemTraChanLe(so);
//		if (kq) {
//			System.out.println("Số chẵn");
//		} else {
//			System.out.println("Số lẻ");
//		}

	}

}
