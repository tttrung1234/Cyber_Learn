function getEle(id){
    return document.getElementById(id);
}

function batDen(){
    var den = getEle("theDen");
    den.src = "imgs/pic_bulbon.gif";
}

function tatDen(){
    var den = getEle("theDen");
    den.src = "imgs/pic_bulboff.gif";
}

function dangNhap(){
    var userName = getEle("username");
    var pass = getEle("password");
    var sectionThongBao = getEle("sectionThongBao");
    var thePThongBao = getEle("thePThongBao");
    if(userName.value == "CyberSoft" && pass.value =="CyberSoft"){
        sectionThongBao.style.backgroundColor = 'green';
        thePThongBao.innerHTML = "Đăng nhập thành công";
    }

}